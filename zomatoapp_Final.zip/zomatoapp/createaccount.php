<?php
session_start();
if(!isset($_SESSION['zomato_user_details']))
{ ?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Account Form</title>
        <?php include 'links.php' ?>
</head>
<body>
<!-- main -->
<div class="main-w3layouts wrapper">
    <h1>Create Account Form</h1>
    <div class="main-agileinfo">
        <div class="agileits-top">
            <form action="#" method="post" id="user-create-account-form">
                <input class="text" type="text" name="username" placeholder="Your Name" required="">
                <input class="text email" type="email" name="email" placeholder="Email" required="">
                <input class="text" type="password" name="password" placeholder="Password" required="">
                <input class="text w3lpass" type="password" name="confirm_password" placeholder="Confirm Password" required="">
                <input type="submit" value="Create Account">
            </form>
            <p>Have an Account? <a href="login.php"> Login Now!</a></p>
        </div>
    </div>
    <!-- copyright -->

    <!-- //copyright -->
    <ul class="colorlib-bubbles">
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
    </ul>
</div>
<!-- //main -->
</body>
</html>
<?php }else{
    header("Location: zomatosearch.php");
}
?>