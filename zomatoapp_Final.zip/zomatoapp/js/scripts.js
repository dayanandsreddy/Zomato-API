
$(document).ready(function () {
    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": true,
        "progressBar": false,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "2000",
        "timeOut": "5000",
        "extendedTimeOut": "2000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };


    $('#user-create-account-form').submit(function (e) {
        e.preventDefault();
        var _form = $(this);

        $.ajax({
            url: "data/createaccount.php",
            type: "POST",
            data: _form.serialize(),
            success: function (data) {
                var decode = JSON.parse(data);
                if(decode.code == 200){
                    toastr.success(decode.message, "");
                    window.location = 'login.php';
                } else{
                    toastr.error(decode.message, "");
                }
            }
        });

    });

    $('#restaurant-submit').click(function () {

        var searchValue = $('#restaurant-search').val();


        if(searchValue != ''){
            $('#ajax-loader').show();

            $.ajax({
                url: "data/getrestorentdata.php",
                type: "POST",
                data: {
                    searchkey:searchValue
                },
                success: function (data) {
                    $('#search-result-response').html(data);
                    $('#ajax-loader').hide();
                }
            });

        }
        else {
            toastr.error("Please Enter A value", "");
        }


    });

    $('#user-login-form').submit(function (e) {
        e.preventDefault();
        var _form = $(this);

        $.ajax({
            url: "data/login.php",
            type: "POST",
            data: _form.serialize(),
            success: function (data) {
                var decode = JSON.parse(data);
                if(decode.code == 200){
                    toastr.success(decode.message, "");
                    window.location = 'index.php';
                }else{
                    toastr.error(decode.message, "");
                }
            }
        });

    });

    $('.feedback-popup-trig').click(function () {
        $('#review-form-model').modal('show');
    });

    $('#review-form').submit(function (e) {
        e.preventDefault();

        var _form = $(this);

        $.ajax({
            url: "data/reviewsubmit.php",
            type: "POST",
            data: _form.serialize(),
            success: function (data) {
                var decode = JSON.parse(data);
                if(decode.code == 200){
                    toastr.success(decode.message, "");
                    window.location.reload();
                }else{
                    toastr.error("Error In submit Review", "");
                }
            }
        });

    });



});