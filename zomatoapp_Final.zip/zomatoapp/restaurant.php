
<?php
include("data/RestData.php");
include("data/Review.php");


include ('data/config.php');
session_start();
if(!isset($_SESSION['zomato_user_details']))
{
    header("Location: login.php");
}else{
    $userData = $_SESSION['zomato_user_details'];

        $rest_id =  $_GET["rest_id"];

        $restDataObj = new RestData();
        $restData = $restDataObj->getRestData($rest_id);

        if($rest_id != null){ ?>
            <!DOCTYPE html>
            <html>
            <head>
                <title>Log In Form</title>
                <?php include 'links.php' ?>
            </head>
            <body>
            <div class="header-block">
                <div class="header-wrap">
                    <div class="user-action">
                        <div class="user-name">
                            <p>Hello <?php  echo $userData['user_name'] ?></p>
                        </div>
                        <div class="logout">
                            <a href="logout.php">Log Out</a>
                        </div>

                    </div>
                </div>

            </div>
            <!-- main -->
            <div class="main-w3layouts wrapper clinics-and-hospitals">
                <script>
                    var restData = <?php echo json_encode($restData); ?>;
                </script>

                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 hospital-list">
                            <div class="list hospital-blog">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <div class="pharmacy-image">
                                                <img src="<?php echo $restData->featured_image ?>" class="image" >
                                            </div>
                                        </div>
                                        <div class="col-sm-8">
                                            <div class="hospital-details">
                                                <h1 class="name"><?php echo $restData->name ?></h1>
                                                <p class="place">Cuisines Type : <?php echo $restData->cuisines ?></p>
                                                <p class="checkup-types">Address : <?php echo $restData->location->address ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="feedback-block">
                                <div class="review-head">
                                    <h2>Feedback</h2>
                                    <button class="feedback-popup-trig btn">Give Feedback</button>
                                </div>
                                <div class="feedback-content">

                                </div>
                            </div>
                        </div>

                        <?php
                        $review = new Review();
                        $reviewsData  = $review->getReviews($db,$rest_id);
                        ?>
                        <?php
                        if($reviewsData != null){
                            foreach ($reviewsData as $singleData){ ?>
                                <div class="col-sm-12 feedback-block">
                                    <div class="review">
                                        <h3 class="name-and-date"><?php echo $singleData['user_name'] ?></h3>
                                        <?php
                                         $percentage = ($singleData['review_value']/5)*100;
                                        ?>
                                        <div class="star-ratings">
                                            <div class="star-ratings-css-top" style="width: <?php echo $percentage ?>%">
                                                <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
                                            </div>
                                            <div class="star-ratings-css-bottom">
                                                <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
                                            </div>
                                        </div>
                                        <p class="review-data"><?php echo $singleData['review_content'] ?></p>
                                    </div>
                                </div>
                       <?php     }
                        }
                        else{ ?>
                            <p>No Reviews yet...</p>
                     <?php   }
                        ?>



                    </div>
                </div>

                <div id="review-form-model" class="modal fade" role="dialog">
                    <div class="modal-dialog">

                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Give Feedback</h4>
                            </div>
                            <div class="modal-body">
                                <div class="review-form">
                                    <form id="review-form">
                                        <input type="hidden" name="rest_id" value="<?php echo $rest_id ?>">
                                        <input type="hidden" name="user_name" value="<?php  echo $userData['user_name'] ?>">
                                        <div class="star-reviews">
                                <span class="star-cb-group">
                                      <input type="radio" id="rating-5" name="review_value" value="5">
                                        <label for="rating-5"></label>
                                      <input type="radio" id="rating-4" name="review_value" value="4">
                                        <label for="rating-4"></label>
                                      <input type="radio" id="rating-3" name="review_value" value="3">
                                        <label for="rating-3"></label>
                                      <input type="radio" id="rating-2" name="review_value" value="2">
                                        <label for="rating-2"></label>
                                      <input type="radio" id="rating-1" name="review_value" value="1" checked="checked">
                                        <label for="rating-1"></label>
                                </span>
                                        </div>
                                        <div class="feedback-data">
                                            <textarea class="feedback-text" name="review_content" placeholder="Write your Feedback" required></textarea>
                                        </div>
                                        <div class="submit-div">
                                            <button type="submit" class="submit-feedback btn">Submit</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>


                <ul class="colorlib-bubbles">
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>
            </div>
            <div class="ajax-loader" id="ajax-loader" >
                <div class="load-content">
                    <img alt="loader" src="https://www.glowship.com/skin/frontend/ultimo/default/images/ajaxloading.gif" class="image">
                </div>
            </div>

            </body>
            </html>
      <?php  }
        else{
            header("Location: login.php");
        }
    ?>

<?php }
?>


