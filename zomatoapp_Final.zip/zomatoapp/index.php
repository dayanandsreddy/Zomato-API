<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 20/11/18
 * Time: 2:29 PM
 */

session_start();
if(!isset($_SESSION['zomato_user_details']))
{
    header("Location: login.php");
}else{
    header("Location: zomatosearch.php");
}