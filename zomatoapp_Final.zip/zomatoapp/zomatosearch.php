<?php

include ('data/config.php');
session_start();
if(!isset($_SESSION['zomato_user_details']))
{
    header("Location: login.php");
}else{
    $userData = $_SESSION['zomato_user_details'];

    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Log In Form</title>
        <?php include 'links.php' ?>
    </head>
    <body>
    <div class="header-block">
        <div class="header-wrap">
            <div class="user-action">
                <div class="user-name">
                    <p>Hello <?php  echo $userData['user_name'] ?></p>
                </div>
                <div class="logout">
                    <a href="logout.php">Log Out</a>
                </div>

            </div>
        </div>

    </div>
    <!-- main -->
    <div class="main-w3layouts wrapper">
        <h1>Search Restaurant</h1>
        <div class="container">
            <div class="row">
                <div class="col-sm-12 ">
                    <div id="imaginary_container">
                        <div class="input-group stylish-input-group">
                            <input type="text" id="restaurant-search" class="form-control"  placeholder="Search for restaurants or cuisines..." >
                            <button type="submit" class="input-group-addonn" id="restaurant-submit">Search</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="search-result-response">

        </div>



        <ul class="colorlib-bubbles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    </div>
    <div class="ajax-loader" id="ajax-loader" >
        <div class="load-content">
            <img alt="loader" src="https://www.glowship.com/skin/frontend/ultimo/default/images/ajaxloading.gif" class="image">
        </div>
    </div>

    </body>
    </html>

<?php }
?>

