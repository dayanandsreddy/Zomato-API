<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 25/11/18
 * Time: 3:27 PM
 */
class Review {

    /**
     * @param $db
     * @param $userdata
     * @return bool
     */
    public function reviewSubmit($db,$resId,$userName,$reviewValue,$reviewContent){

        $sql = "INSERT INTO zomato_review (rest_id, user_name, review_value,review_content) VALUES ('".$resId."','".$userName."','".$reviewValue."','".$reviewContent."')";
        $db->query($sql);
    }
    public function getReviews($db,$restId){
        $sql = "SELECT * FROM zomato_review WHERE rest_id = ".$restId;
        $result = $db->query($sql);
        $notesCollectionData = array();
        if ($result->num_rows > 0) {

            while ($row = $result->fetch_assoc()){
                array_push($notesCollectionData,$row);
            }
            return $notesCollectionData;
        } else {
            return null;
        }
    }

}