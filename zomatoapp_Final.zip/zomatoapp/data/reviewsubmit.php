<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 20/11/18
 * Time: 11:29 PM
 */

include("config.php");
include("Review.php");
session_start();


if($_SERVER["REQUEST_METHOD"] == "POST") {
    // username and password sent from form

    $resId = $_POST['rest_id'];
    $userName = $_POST['user_name'];
    $reviewValue = $_POST['review_value'];
    $reviewContent = $_POST['review_content'];

    $review = new Review();
    $review->reviewSubmit($db,$resId,$userName,$reviewValue,$reviewContent);

    $response = array('code'=>200,'message'=>'Review Submitted');

    echo json_encode($response);



}