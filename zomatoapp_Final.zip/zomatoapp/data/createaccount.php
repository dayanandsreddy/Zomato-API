<?php
include("config.php");
session_start();
class accountCreate {

    /**
     * @param $db
     * @param $userdata
     * @return bool
     */
    public function isUserPresent($db,$userEmail){
        $sql = "SELECT * FROM users WHERE user_email = '".$userEmail."'";
        $result = $db->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return $row;
        } else {
           return false;
        }
    }
    public function createUser($db,$userName,$email,$password){
        $sql = "INSERT INTO users (user_name, user_email, user_password) VALUES ('".$userName."', '".$email."','".$password."')";
        $db->query($sql);
    }

}
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // username and password sent from form

    $userName = $_POST['username'];
    $userEmail = $_POST['email'];
    $password = $_POST['password'];
    $conformPassword = $_POST['confirm_password'];

    $accountcreate = new accountCreate();
    $userData = $accountcreate->isUserPresent($db,$userEmail);
    $response = array();

    if($userData == false){
        if($password != $conformPassword){
            $response = array('code'=>500,'message'=>'Passwords are not equal');
        } else{
            $accountcreate->createUser($db,$userName,$userEmail,$password);;
            $response = array('code'=>200,'message'=>'Account Created');
        }
    }else{
        $response = array('code'=>500,'message'=>'Unable to create your Account');
    }

    echo json_encode($response);
}
?>


