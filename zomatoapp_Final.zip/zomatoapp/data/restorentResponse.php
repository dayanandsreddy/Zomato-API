<script>
    var restorentData = <?php echo json_encode($restorentData) ?>;
</script>
<div class="container">
    <div class="row">
        <?php foreach ( $restorentData->restaurants as $restorent ){ ?>
            <div class="col-sm-3">
                <div class="restaurant">
                    <div class="infos_left">
                        <div class="image_container">
                            <a href="restaurant.php?rest_id=<?php echo $restorent->restaurant->id ?>">
                                <img src="<?php echo $restorent->restaurant->featured_image ?>">
                            </a>
                        </div>
                        <div class="block_infos">
                            <a href="restaurant.php?rest_id=<?php echo $restorent->restaurant->id ?>">
                                <h2><?php echo $restorent->restaurant->name ?></h2>
                            </a>
                            <div class="small-info">

                                <div class="lists">
                                    <span class="type">Price :</span>
                                    <span class="value"><?php echo $restorent->restaurant->currency ?></span>
                                </div>
                                <div class="lists cuisines">
                                    <span class="type">Cuisines :</span>
                                    <span class="value"><?php echo $restorent->restaurant->cuisines ?></span>
                                </div>
                                <div class="lists">
                                    <span class="type">Zomato Users Rating</span>
                                    <span class="value"><?php echo $restorent->restaurant->user_rating->aggregate_rating ?></span>
                                </div>

                            </div>
                            <div class="description_block">
                                <p>Address:</p>
                                <p class="address"><?php echo $restorent->restaurant->location->address ?></p>
                            </div>
                            <div class="url-tab">
                                <a target="_blank" href="<?php echo $restorent->restaurant->events_url ?>">Link To Zomato</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
     <?php   }  ?>
    </div>
</div>

