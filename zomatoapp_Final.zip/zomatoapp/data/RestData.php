<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 25/11/18
 * Time: 1:03 PM
 */
class RestData{
    public function getRestData($restId){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://developers.zomato.com/api/v2.1/restaurant?res_id=".$restId);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        $headers = array(
            "Accept: application/json",
            "User-Key: c01b713ae660d0fc4a2e38e315cc8805"
        );
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close ($ch);

        return json_decode($result);
    }
}