<?php
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // username and password sent from form

    $searchKey = urlencode($_POST['searchkey']);


            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "https://developers.zomato.com/api/v2.1/search?q=".$searchKey."&start=0");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
            $headers = array(
                "Accept: application/json",
                "User-Key: c01b713ae660d0fc4a2e38e315cc8805"
            );
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            $result = curl_exec($ch);
            if (curl_errno($ch)) {
                echo 'Error:' . curl_error($ch);
            }
            curl_close ($ch);

            $restorentData = json_decode($result);
             include('restorentResponse.php');




}